#!/bin/sh

# DIPLOMAT_HOME Points to the Diplomat install directory
#               e.g /opt/coviant/diplomat-j
#               You should edit the definition of DIPLOMAT_HOME
#               if you have not installed Diplomat in 
#               the default directory.  If you are executing
#               remotely, enter the complete pathname to the 
#               DIPLOMAT_HOME directory - 
#               e.g. //pathname/opt/coviant/diplomat-trial

DIPLOMAT_HOME=/opt/coviant/diplomat-trial

SCRIPTING_HOME="$DIPLOMAT_HOME/scriptingAgent"
"$DIPLOMAT_HOME/jre/bin/java" -cp "$SCRIPTING_HOME/diplomatScriptingAgent.jar" diplomat.scripting.ScriptingClient "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9"

exit "$?"


